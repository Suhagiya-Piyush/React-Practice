import React from 'react'

export const Create = () => {
  return (
    <div>Create</div>
  )
}
